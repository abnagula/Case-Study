package com.thebank.dao;

import java.util.Set;

import com.thebank.model.Payee;

public interface IPayeeDao {

	public boolean addPayee(Payee payee);
	public Payee getPayeeFromPayeeAccountId(long payeeAccountId);
	public Set<Payee> getAllPayees();
	public Set<Payee> getAllPayeeOfAccountId(long accountId);
}
