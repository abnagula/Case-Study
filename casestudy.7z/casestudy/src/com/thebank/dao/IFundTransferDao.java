package com.thebank.dao;

import java.util.Set;

import com.thebank.model.FundTransfer;

public interface IFundTransferDao {

	public boolean addFundTransfer(FundTransfer fundTransfer);
	public FundTransfer getFundTransferFromFundTranferId(long fundTranferId);
	public Set<FundTransfer> getAllFundTransfers();
	public Set<FundTransfer> getAllFundTransfersFromAccountId(long accountId);
	
}
