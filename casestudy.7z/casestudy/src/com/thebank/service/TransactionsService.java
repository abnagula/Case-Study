package com.thebank.service;

import java.time.LocalDate;
import java.util.Set;

import com.thebank.dao.ITransactionsDao;
import com.thebank.dao.TransactionsDao;
import com.thebank.model.Transaction;

public class TransactionsService implements ITransactionsService{
	ITransactionsDao transactionsDao = new TransactionsDao();
	
	public TransactionsService() {

	}
	
	public TransactionsService(ITransactionsDao transactionDao) {
		this.transactionsDao=transactionDao;
	}
	
	@Override
	public boolean addTransaction(Transaction transaction) {
		if(transaction==null)
		{
			throw new IllegalArgumentException();
		}
		return transactionsDao.addTransaction(transaction);
	}

	@Override
	public Transaction getTransactionFormTransactionId(long transactionId) {
		return transactionsDao.getTransactionFormTransactionId(transactionId);
	}

	@Override
	public Set<Transaction> getAllTransaction() {
		return transactionsDao.getAllTransaction();
	}

	@Override
	public Set<Transaction> getTransactionsForAccount(long accountId) {
		return transactionsDao.getTransactionsForAccount(accountId);
	}

	@Override
	public Set<Transaction> getTransactionsForCustomer(long customerId) {
		return transactionsDao.getTransactionsForCustomer(customerId);
	}

	@Override
	public Set<Transaction> getLastNTransactionsForAccount(long accountId, int count) {
		return transactionsDao.getLastNTransactionsForAccount(accountId, count);
	}
	
	@Override
	public Set<Transaction> getTransactionsForCustomerInDateRange(long customerId,LocalDate fromDate, LocalDate toDate){
		return transactionsDao.getTransactionsForCustomerInDateRange(customerId, fromDate, toDate);
	}

	@Override
	public Set<Transaction> getDailyTransactions() {
		return transactionsDao.getDailyTransactions();
	}

	@Override
	public Set<Transaction> getMonthlyTransactions() {
		return transactionsDao.getMonthlyTransactions();
	}

	@Override
	public Set<Transaction> getQuarterlyTransactions() {
		return transactionsDao.getQuarterlyTransactions();
	}

	@Override
	public Set<Transaction> getYearlyTransactions() {
		return transactionsDao.getYearlyTransactions();
	}
	
	
	
}
