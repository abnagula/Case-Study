package com.thebank.model;

public enum AccountType {
	
	SAVINGS,CURRENT,FD,RD;

}
